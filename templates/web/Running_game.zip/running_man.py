from turtle import Turtle
class Running_man(Turtle):
	dx = 0
	dy = 0
	width = 128
	height = 161
	def __init__(self, x, y, dx, dy):
		Turtle.__init__(self)
		self.pu()
		self.goto(x, y)
		self.dx = dx
		self.dy = dy
		self.shape("turtle")


	def move(self, screen_bottom_edge):
		oldy = self.ycor()
		newy = oldy + self.dy
		if self.ycor() != screen_bottom_edge +70:
			self.dy -=1
		if self.ycor() <= screen_bottom_edge:
			self.dy=0
			newy=screen_bottom_edge +70
		self.goto(-320,newy)
	def left_side(self):
		return self.xcor()-(self.width/2)
	def right_side(self):
		return self.xcor()+(self.width/2)
	def top_side(self):
		return self.ycor()+(self.height/2)
	def bottom_side(self):
		return self.ycor()-(self.height/2)